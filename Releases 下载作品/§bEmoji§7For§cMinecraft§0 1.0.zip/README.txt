


   名称: Emoji For Minecraft
   作者: 零雾〇五 Fogg05
   团队: 异创Special 我的世界组件开发组

● 作品基于 Fluent Emoji
https://github.com/microsoft/fluentui-emoji

● 作品发布
https://github.com/Fogg05/emoji-for-minecraft



   Title: Emoji For Minecraft
   Author: 零雾〇五 Fogg05
   Team: 异创Special Minecraft MOD Development

● This pack is based on Fluent Emoji:
https://github.com/microsoft/fluentui-emoji

● Github of this pack:
https://github.com/Fogg05/emoji-for-minecraft



